﻿namespace HuoChessW8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_exit = new System.Windows.Forms.Button();
            this.pictureBoxA2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxB2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxC2 = new System.Windows.Forms.PictureBox();
            this.button_Play = new System.Windows.Forms.Button();
            this.radioButton_White = new System.Windows.Forms.RadioButton();
            this.radioButton_Black = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBoxF2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxE2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxD2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxH2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxG2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxH3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxG3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxF3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxE3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxD3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxC3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxB3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxA3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxH4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxG4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxF4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxE4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxD4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxC4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxB4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxA4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxH5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxG5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxF5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxE5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxD5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxC5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxB5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxA5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxH6 = new System.Windows.Forms.PictureBox();
            this.pictureBoxG6 = new System.Windows.Forms.PictureBox();
            this.pictureBoxF6 = new System.Windows.Forms.PictureBox();
            this.pictureBoxE6 = new System.Windows.Forms.PictureBox();
            this.pictureBoxD6 = new System.Windows.Forms.PictureBox();
            this.pictureBoxC6 = new System.Windows.Forms.PictureBox();
            this.pictureBoxB6 = new System.Windows.Forms.PictureBox();
            this.pictureBoxA6 = new System.Windows.Forms.PictureBox();
            this.pictureBoxH7 = new System.Windows.Forms.PictureBox();
            this.pictureBoxG7 = new System.Windows.Forms.PictureBox();
            this.pictureBoxF7 = new System.Windows.Forms.PictureBox();
            this.pictureBoxE7 = new System.Windows.Forms.PictureBox();
            this.pictureBoxD7 = new System.Windows.Forms.PictureBox();
            this.pictureBoxC7 = new System.Windows.Forms.PictureBox();
            this.pictureBoxB7 = new System.Windows.Forms.PictureBox();
            this.pictureBoxA7 = new System.Windows.Forms.PictureBox();
            this.pictureBoxH8 = new System.Windows.Forms.PictureBox();
            this.pictureBoxG8 = new System.Windows.Forms.PictureBox();
            this.pictureBoxF8 = new System.Windows.Forms.PictureBox();
            this.pictureBoxE8 = new System.Windows.Forms.PictureBox();
            this.pictureBoxD8 = new System.Windows.Forms.PictureBox();
            this.pictureBoxC8 = new System.Windows.Forms.PictureBox();
            this.pictureBoxB8 = new System.Windows.Forms.PictureBox();
            this.pictureBoxA8 = new System.Windows.Forms.PictureBox();
            this.pictureBoxH1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxG1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxF1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxE1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxD1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxC1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxB1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxA1 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxA2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxB2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxC2)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxF2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxE2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxD2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxH2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxG2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxH3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxG3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxF3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxE3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxD3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxC3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxB3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxA3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxH4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxG4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxF4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxE4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxD4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxC4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxB4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxA4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxH5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxG5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxF5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxE5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxD5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxC5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxB5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxA5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxH6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxG6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxF6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxE6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxD6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxC6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxB6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxA6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxH7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxG7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxF7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxE7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxD7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxC7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxB7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxA7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxH8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxG8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxF8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxE8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxD8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxC8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxB8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxA8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxH1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxG1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxF1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxE1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxD1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxC1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxB1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxA1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_exit
            // 
            this.button_exit.Location = new System.Drawing.Point(495, 298);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(75, 23);
            this.button_exit.TabIndex = 0;
            this.button_exit.Text = "Exit";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // pictureBoxA2
            // 
            this.pictureBoxA2.BackColor = System.Drawing.Color.White;
            this.pictureBoxA2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxA2.Location = new System.Drawing.Point(50, 333);
            this.pictureBoxA2.Name = "pictureBoxA2";
            this.pictureBoxA2.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxA2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxA2.TabIndex = 1;
            this.pictureBoxA2.TabStop = false;
            this.pictureBoxA2.Click += new System.EventHandler(this.pictureBoxA2_Click);
            // 
            // pictureBoxB2
            // 
            this.pictureBoxB2.BackColor = System.Drawing.Color.Black;
            this.pictureBoxB2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxB2.Location = new System.Drawing.Point(100, 333);
            this.pictureBoxB2.Name = "pictureBoxB2";
            this.pictureBoxB2.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxB2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxB2.TabIndex = 3;
            this.pictureBoxB2.TabStop = false;
            this.pictureBoxB2.Click += new System.EventHandler(this.pictureBoxB2_Click);
            // 
            // pictureBoxC2
            // 
            this.pictureBoxC2.BackColor = System.Drawing.Color.White;
            this.pictureBoxC2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxC2.Location = new System.Drawing.Point(150, 333);
            this.pictureBoxC2.Name = "pictureBoxC2";
            this.pictureBoxC2.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxC2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxC2.TabIndex = 4;
            this.pictureBoxC2.TabStop = false;
            this.pictureBoxC2.Click += new System.EventHandler(this.pictureBoxC2_Click);
            // 
            // button_Play
            // 
            this.button_Play.Location = new System.Drawing.Point(495, 269);
            this.button_Play.Name = "button_Play";
            this.button_Play.Size = new System.Drawing.Size(75, 23);
            this.button_Play.TabIndex = 6;
            this.button_Play.Text = "Play";
            this.button_Play.UseVisualStyleBackColor = true;
            this.button_Play.Click += new System.EventHandler(this.button_Play_Click);
            // 
            // radioButton_White
            // 
            this.radioButton_White.AutoSize = true;
            this.radioButton_White.Location = new System.Drawing.Point(17, 31);
            this.radioButton_White.Name = "radioButton_White";
            this.radioButton_White.Size = new System.Drawing.Size(53, 17);
            this.radioButton_White.TabIndex = 7;
            this.radioButton_White.TabStop = true;
            this.radioButton_White.Text = "White";
            this.radioButton_White.UseVisualStyleBackColor = true;
            this.radioButton_White.Click += new System.EventHandler(this.radioButton_White_Click);
            // 
            // radioButton_Black
            // 
            this.radioButton_Black.AutoSize = true;
            this.radioButton_Black.Location = new System.Drawing.Point(17, 51);
            this.radioButton_Black.Name = "radioButton_Black";
            this.radioButton_Black.Size = new System.Drawing.Size(52, 17);
            this.radioButton_Black.TabIndex = 8;
            this.radioButton_Black.TabStop = true;
            this.radioButton_Black.Text = "Black";
            this.radioButton_Black.UseVisualStyleBackColor = true;
            this.radioButton_Black.Click += new System.EventHandler(this.radioButton_Black_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton_White);
            this.groupBox1.Controls.Add(this.radioButton_Black);
            this.groupBox1.Location = new System.Drawing.Point(480, 161);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(103, 94);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Player Colour";
            // 
            // pictureBoxF2
            // 
            this.pictureBoxF2.BackColor = System.Drawing.Color.Black;
            this.pictureBoxF2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxF2.Location = new System.Drawing.Point(300, 333);
            this.pictureBoxF2.Name = "pictureBoxF2";
            this.pictureBoxF2.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxF2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxF2.TabIndex = 12;
            this.pictureBoxF2.TabStop = false;
            this.pictureBoxF2.Click += new System.EventHandler(this.pictureBoxF2_Click);
            // 
            // pictureBoxE2
            // 
            this.pictureBoxE2.BackColor = System.Drawing.Color.White;
            this.pictureBoxE2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxE2.Location = new System.Drawing.Point(250, 333);
            this.pictureBoxE2.Name = "pictureBoxE2";
            this.pictureBoxE2.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxE2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxE2.TabIndex = 11;
            this.pictureBoxE2.TabStop = false;
            this.pictureBoxE2.Click += new System.EventHandler(this.pictureBoxE2_Click);
            // 
            // pictureBoxD2
            // 
            this.pictureBoxD2.BackColor = System.Drawing.Color.Black;
            this.pictureBoxD2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxD2.Location = new System.Drawing.Point(200, 333);
            this.pictureBoxD2.Name = "pictureBoxD2";
            this.pictureBoxD2.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxD2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxD2.TabIndex = 10;
            this.pictureBoxD2.TabStop = false;
            this.pictureBoxD2.Click += new System.EventHandler(this.pictureBoxD2_Click);
            // 
            // pictureBoxH2
            // 
            this.pictureBoxH2.BackColor = System.Drawing.Color.Black;
            this.pictureBoxH2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxH2.Location = new System.Drawing.Point(400, 333);
            this.pictureBoxH2.Name = "pictureBoxH2";
            this.pictureBoxH2.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxH2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxH2.TabIndex = 14;
            this.pictureBoxH2.TabStop = false;
            this.pictureBoxH2.Click += new System.EventHandler(this.pictureBoxH2_Click);
            // 
            // pictureBoxG2
            // 
            this.pictureBoxG2.BackColor = System.Drawing.Color.White;
            this.pictureBoxG2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxG2.Location = new System.Drawing.Point(350, 333);
            this.pictureBoxG2.Name = "pictureBoxG2";
            this.pictureBoxG2.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxG2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxG2.TabIndex = 13;
            this.pictureBoxG2.TabStop = false;
            this.pictureBoxG2.Click += new System.EventHandler(this.pictureBoxG2_Click);
            // 
            // pictureBoxH3
            // 
            this.pictureBoxH3.BackColor = System.Drawing.Color.White;
            this.pictureBoxH3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxH3.Location = new System.Drawing.Point(400, 283);
            this.pictureBoxH3.Name = "pictureBoxH3";
            this.pictureBoxH3.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxH3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxH3.TabIndex = 22;
            this.pictureBoxH3.TabStop = false;
            this.pictureBoxH3.Click += new System.EventHandler(this.pictureBoxH3_Click);
            // 
            // pictureBoxG3
            // 
            this.pictureBoxG3.BackColor = System.Drawing.Color.Black;
            this.pictureBoxG3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxG3.Location = new System.Drawing.Point(350, 283);
            this.pictureBoxG3.Name = "pictureBoxG3";
            this.pictureBoxG3.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxG3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxG3.TabIndex = 21;
            this.pictureBoxG3.TabStop = false;
            this.pictureBoxG3.Click += new System.EventHandler(this.pictureBoxG3_Click);
            // 
            // pictureBoxF3
            // 
            this.pictureBoxF3.BackColor = System.Drawing.Color.White;
            this.pictureBoxF3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxF3.Location = new System.Drawing.Point(300, 283);
            this.pictureBoxF3.Name = "pictureBoxF3";
            this.pictureBoxF3.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxF3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxF3.TabIndex = 20;
            this.pictureBoxF3.TabStop = false;
            this.pictureBoxF3.Click += new System.EventHandler(this.pictureBoxF3_Click);
            // 
            // pictureBoxE3
            // 
            this.pictureBoxE3.BackColor = System.Drawing.Color.Black;
            this.pictureBoxE3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxE3.Location = new System.Drawing.Point(250, 283);
            this.pictureBoxE3.Name = "pictureBoxE3";
            this.pictureBoxE3.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxE3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxE3.TabIndex = 19;
            this.pictureBoxE3.TabStop = false;
            this.pictureBoxE3.Click += new System.EventHandler(this.pictureBoxE3_Click);
            // 
            // pictureBoxD3
            // 
            this.pictureBoxD3.BackColor = System.Drawing.Color.White;
            this.pictureBoxD3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxD3.Location = new System.Drawing.Point(200, 283);
            this.pictureBoxD3.Name = "pictureBoxD3";
            this.pictureBoxD3.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxD3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxD3.TabIndex = 18;
            this.pictureBoxD3.TabStop = false;
            this.pictureBoxD3.Click += new System.EventHandler(this.pictureBoxD3_Click);
            // 
            // pictureBoxC3
            // 
            this.pictureBoxC3.BackColor = System.Drawing.Color.Black;
            this.pictureBoxC3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxC3.Location = new System.Drawing.Point(150, 283);
            this.pictureBoxC3.Name = "pictureBoxC3";
            this.pictureBoxC3.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxC3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxC3.TabIndex = 17;
            this.pictureBoxC3.TabStop = false;
            this.pictureBoxC3.Click += new System.EventHandler(this.pictureBoxC3_Click);
            // 
            // pictureBoxB3
            // 
            this.pictureBoxB3.BackColor = System.Drawing.Color.White;
            this.pictureBoxB3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxB3.Location = new System.Drawing.Point(100, 283);
            this.pictureBoxB3.Name = "pictureBoxB3";
            this.pictureBoxB3.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxB3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxB3.TabIndex = 16;
            this.pictureBoxB3.TabStop = false;
            this.pictureBoxB3.Click += new System.EventHandler(this.pictureBoxB3_Click);
            // 
            // pictureBoxA3
            // 
            this.pictureBoxA3.BackColor = System.Drawing.Color.Black;
            this.pictureBoxA3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxA3.Location = new System.Drawing.Point(50, 283);
            this.pictureBoxA3.Name = "pictureBoxA3";
            this.pictureBoxA3.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxA3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxA3.TabIndex = 15;
            this.pictureBoxA3.TabStop = false;
            this.pictureBoxA3.Click += new System.EventHandler(this.pictureBoxA3_Click);
            // 
            // pictureBoxH4
            // 
            this.pictureBoxH4.BackColor = System.Drawing.Color.Black;
            this.pictureBoxH4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxH4.Location = new System.Drawing.Point(400, 233);
            this.pictureBoxH4.Name = "pictureBoxH4";
            this.pictureBoxH4.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxH4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxH4.TabIndex = 30;
            this.pictureBoxH4.TabStop = false;
            this.pictureBoxH4.Click += new System.EventHandler(this.pictureBoxH4_Click);
            // 
            // pictureBoxG4
            // 
            this.pictureBoxG4.BackColor = System.Drawing.Color.White;
            this.pictureBoxG4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxG4.Location = new System.Drawing.Point(350, 233);
            this.pictureBoxG4.Name = "pictureBoxG4";
            this.pictureBoxG4.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxG4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxG4.TabIndex = 29;
            this.pictureBoxG4.TabStop = false;
            this.pictureBoxG4.Click += new System.EventHandler(this.pictureBoxG4_Click);
            // 
            // pictureBoxF4
            // 
            this.pictureBoxF4.BackColor = System.Drawing.Color.Black;
            this.pictureBoxF4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxF4.Location = new System.Drawing.Point(300, 233);
            this.pictureBoxF4.Name = "pictureBoxF4";
            this.pictureBoxF4.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxF4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxF4.TabIndex = 28;
            this.pictureBoxF4.TabStop = false;
            this.pictureBoxF4.Click += new System.EventHandler(this.pictureBoxF4_Click);
            // 
            // pictureBoxE4
            // 
            this.pictureBoxE4.BackColor = System.Drawing.Color.White;
            this.pictureBoxE4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxE4.Location = new System.Drawing.Point(250, 233);
            this.pictureBoxE4.Name = "pictureBoxE4";
            this.pictureBoxE4.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxE4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxE4.TabIndex = 27;
            this.pictureBoxE4.TabStop = false;
            this.pictureBoxE4.Click += new System.EventHandler(this.pictureBoxE4_Click);
            // 
            // pictureBoxD4
            // 
            this.pictureBoxD4.BackColor = System.Drawing.Color.Black;
            this.pictureBoxD4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxD4.Location = new System.Drawing.Point(200, 233);
            this.pictureBoxD4.Name = "pictureBoxD4";
            this.pictureBoxD4.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxD4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxD4.TabIndex = 26;
            this.pictureBoxD4.TabStop = false;
            this.pictureBoxD4.Click += new System.EventHandler(this.pictureBoxD4_Click);
            // 
            // pictureBoxC4
            // 
            this.pictureBoxC4.BackColor = System.Drawing.Color.White;
            this.pictureBoxC4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxC4.Location = new System.Drawing.Point(150, 233);
            this.pictureBoxC4.Name = "pictureBoxC4";
            this.pictureBoxC4.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxC4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxC4.TabIndex = 25;
            this.pictureBoxC4.TabStop = false;
            this.pictureBoxC4.Click += new System.EventHandler(this.pictureBoxC4_Click);
            // 
            // pictureBoxB4
            // 
            this.pictureBoxB4.BackColor = System.Drawing.Color.Black;
            this.pictureBoxB4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxB4.Location = new System.Drawing.Point(100, 233);
            this.pictureBoxB4.Name = "pictureBoxB4";
            this.pictureBoxB4.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxB4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxB4.TabIndex = 24;
            this.pictureBoxB4.TabStop = false;
            this.pictureBoxB4.Click += new System.EventHandler(this.pictureBoxB4_Click);
            // 
            // pictureBoxA4
            // 
            this.pictureBoxA4.BackColor = System.Drawing.Color.White;
            this.pictureBoxA4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxA4.Location = new System.Drawing.Point(50, 233);
            this.pictureBoxA4.Name = "pictureBoxA4";
            this.pictureBoxA4.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxA4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxA4.TabIndex = 23;
            this.pictureBoxA4.TabStop = false;
            this.pictureBoxA4.Click += new System.EventHandler(this.pictureBoxA4_Click);
            // 
            // pictureBoxH5
            // 
            this.pictureBoxH5.BackColor = System.Drawing.Color.White;
            this.pictureBoxH5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxH5.Location = new System.Drawing.Point(400, 183);
            this.pictureBoxH5.Name = "pictureBoxH5";
            this.pictureBoxH5.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxH5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxH5.TabIndex = 38;
            this.pictureBoxH5.TabStop = false;
            this.pictureBoxH5.Click += new System.EventHandler(this.pictureBoxH5_Click);
            // 
            // pictureBoxG5
            // 
            this.pictureBoxG5.BackColor = System.Drawing.Color.Black;
            this.pictureBoxG5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxG5.Location = new System.Drawing.Point(350, 183);
            this.pictureBoxG5.Name = "pictureBoxG5";
            this.pictureBoxG5.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxG5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxG5.TabIndex = 37;
            this.pictureBoxG5.TabStop = false;
            this.pictureBoxG5.Click += new System.EventHandler(this.pictureBoxG5_Click);
            // 
            // pictureBoxF5
            // 
            this.pictureBoxF5.BackColor = System.Drawing.Color.White;
            this.pictureBoxF5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxF5.Location = new System.Drawing.Point(300, 183);
            this.pictureBoxF5.Name = "pictureBoxF5";
            this.pictureBoxF5.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxF5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxF5.TabIndex = 36;
            this.pictureBoxF5.TabStop = false;
            this.pictureBoxF5.Click += new System.EventHandler(this.pictureBoxF5_Click);
            // 
            // pictureBoxE5
            // 
            this.pictureBoxE5.BackColor = System.Drawing.Color.Black;
            this.pictureBoxE5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxE5.Location = new System.Drawing.Point(250, 183);
            this.pictureBoxE5.Name = "pictureBoxE5";
            this.pictureBoxE5.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxE5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxE5.TabIndex = 35;
            this.pictureBoxE5.TabStop = false;
            this.pictureBoxE5.Click += new System.EventHandler(this.pictureBoxE5_Click);
            // 
            // pictureBoxD5
            // 
            this.pictureBoxD5.BackColor = System.Drawing.Color.White;
            this.pictureBoxD5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxD5.Location = new System.Drawing.Point(200, 183);
            this.pictureBoxD5.Name = "pictureBoxD5";
            this.pictureBoxD5.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxD5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxD5.TabIndex = 34;
            this.pictureBoxD5.TabStop = false;
            this.pictureBoxD5.Click += new System.EventHandler(this.pictureBoxD5_Click);
            // 
            // pictureBoxC5
            // 
            this.pictureBoxC5.BackColor = System.Drawing.Color.Black;
            this.pictureBoxC5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxC5.Location = new System.Drawing.Point(150, 183);
            this.pictureBoxC5.Name = "pictureBoxC5";
            this.pictureBoxC5.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxC5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxC5.TabIndex = 33;
            this.pictureBoxC5.TabStop = false;
            this.pictureBoxC5.Click += new System.EventHandler(this.pictureBoxC5_Click);
            // 
            // pictureBoxB5
            // 
            this.pictureBoxB5.BackColor = System.Drawing.Color.White;
            this.pictureBoxB5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxB5.Location = new System.Drawing.Point(100, 183);
            this.pictureBoxB5.Name = "pictureBoxB5";
            this.pictureBoxB5.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxB5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxB5.TabIndex = 32;
            this.pictureBoxB5.TabStop = false;
            this.pictureBoxB5.Click += new System.EventHandler(this.pictureBoxB5_Click);
            // 
            // pictureBoxA5
            // 
            this.pictureBoxA5.BackColor = System.Drawing.Color.Black;
            this.pictureBoxA5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxA5.Location = new System.Drawing.Point(50, 183);
            this.pictureBoxA5.Name = "pictureBoxA5";
            this.pictureBoxA5.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxA5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxA5.TabIndex = 31;
            this.pictureBoxA5.TabStop = false;
            this.pictureBoxA5.Click += new System.EventHandler(this.pictureBoxA5_Click);
            // 
            // pictureBoxH6
            // 
            this.pictureBoxH6.BackColor = System.Drawing.Color.Black;
            this.pictureBoxH6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxH6.Location = new System.Drawing.Point(400, 133);
            this.pictureBoxH6.Name = "pictureBoxH6";
            this.pictureBoxH6.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxH6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxH6.TabIndex = 46;
            this.pictureBoxH6.TabStop = false;
            this.pictureBoxH6.Click += new System.EventHandler(this.pictureBoxH6_Click);
            // 
            // pictureBoxG6
            // 
            this.pictureBoxG6.BackColor = System.Drawing.Color.White;
            this.pictureBoxG6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxG6.Location = new System.Drawing.Point(350, 133);
            this.pictureBoxG6.Name = "pictureBoxG6";
            this.pictureBoxG6.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxG6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxG6.TabIndex = 45;
            this.pictureBoxG6.TabStop = false;
            this.pictureBoxG6.Click += new System.EventHandler(this.pictureBoxG6_Click);
            // 
            // pictureBoxF6
            // 
            this.pictureBoxF6.BackColor = System.Drawing.Color.Black;
            this.pictureBoxF6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxF6.Location = new System.Drawing.Point(300, 133);
            this.pictureBoxF6.Name = "pictureBoxF6";
            this.pictureBoxF6.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxF6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxF6.TabIndex = 44;
            this.pictureBoxF6.TabStop = false;
            this.pictureBoxF6.Click += new System.EventHandler(this.pictureBoxF6_Click);
            // 
            // pictureBoxE6
            // 
            this.pictureBoxE6.BackColor = System.Drawing.Color.White;
            this.pictureBoxE6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxE6.Location = new System.Drawing.Point(250, 133);
            this.pictureBoxE6.Name = "pictureBoxE6";
            this.pictureBoxE6.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxE6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxE6.TabIndex = 43;
            this.pictureBoxE6.TabStop = false;
            this.pictureBoxE6.Click += new System.EventHandler(this.pictureBoxE6_Click);
            // 
            // pictureBoxD6
            // 
            this.pictureBoxD6.BackColor = System.Drawing.Color.Black;
            this.pictureBoxD6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxD6.Location = new System.Drawing.Point(200, 133);
            this.pictureBoxD6.Name = "pictureBoxD6";
            this.pictureBoxD6.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxD6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxD6.TabIndex = 42;
            this.pictureBoxD6.TabStop = false;
            this.pictureBoxD6.Click += new System.EventHandler(this.pictureBoxD6_Click);
            // 
            // pictureBoxC6
            // 
            this.pictureBoxC6.BackColor = System.Drawing.Color.White;
            this.pictureBoxC6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxC6.Location = new System.Drawing.Point(150, 133);
            this.pictureBoxC6.Name = "pictureBoxC6";
            this.pictureBoxC6.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxC6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxC6.TabIndex = 41;
            this.pictureBoxC6.TabStop = false;
            this.pictureBoxC6.Click += new System.EventHandler(this.pictureBoxC6_Click);
            // 
            // pictureBoxB6
            // 
            this.pictureBoxB6.BackColor = System.Drawing.Color.Black;
            this.pictureBoxB6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxB6.Location = new System.Drawing.Point(100, 133);
            this.pictureBoxB6.Name = "pictureBoxB6";
            this.pictureBoxB6.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxB6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxB6.TabIndex = 40;
            this.pictureBoxB6.TabStop = false;
            this.pictureBoxB6.Click += new System.EventHandler(this.pictureBoxB6_Click);
            // 
            // pictureBoxA6
            // 
            this.pictureBoxA6.BackColor = System.Drawing.Color.White;
            this.pictureBoxA6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxA6.Location = new System.Drawing.Point(50, 133);
            this.pictureBoxA6.Name = "pictureBoxA6";
            this.pictureBoxA6.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxA6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxA6.TabIndex = 39;
            this.pictureBoxA6.TabStop = false;
            this.pictureBoxA6.Click += new System.EventHandler(this.pictureBoxA6_Click);
            // 
            // pictureBoxH7
            // 
            this.pictureBoxH7.BackColor = System.Drawing.Color.White;
            this.pictureBoxH7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxH7.Location = new System.Drawing.Point(400, 83);
            this.pictureBoxH7.Name = "pictureBoxH7";
            this.pictureBoxH7.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxH7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxH7.TabIndex = 54;
            this.pictureBoxH7.TabStop = false;
            this.pictureBoxH7.Click += new System.EventHandler(this.pictureBoxH7_Click);
            // 
            // pictureBoxG7
            // 
            this.pictureBoxG7.BackColor = System.Drawing.Color.Black;
            this.pictureBoxG7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxG7.Location = new System.Drawing.Point(350, 83);
            this.pictureBoxG7.Name = "pictureBoxG7";
            this.pictureBoxG7.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxG7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxG7.TabIndex = 53;
            this.pictureBoxG7.TabStop = false;
            this.pictureBoxG7.Click += new System.EventHandler(this.pictureBoxG7_Click);
            // 
            // pictureBoxF7
            // 
            this.pictureBoxF7.BackColor = System.Drawing.Color.White;
            this.pictureBoxF7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxF7.Location = new System.Drawing.Point(300, 83);
            this.pictureBoxF7.Name = "pictureBoxF7";
            this.pictureBoxF7.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxF7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxF7.TabIndex = 52;
            this.pictureBoxF7.TabStop = false;
            this.pictureBoxF7.Click += new System.EventHandler(this.pictureBoxF7_Click);
            // 
            // pictureBoxE7
            // 
            this.pictureBoxE7.BackColor = System.Drawing.Color.Black;
            this.pictureBoxE7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxE7.Location = new System.Drawing.Point(250, 83);
            this.pictureBoxE7.Name = "pictureBoxE7";
            this.pictureBoxE7.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxE7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxE7.TabIndex = 51;
            this.pictureBoxE7.TabStop = false;
            this.pictureBoxE7.Click += new System.EventHandler(this.pictureBoxE7_Click);
            // 
            // pictureBoxD7
            // 
            this.pictureBoxD7.BackColor = System.Drawing.Color.White;
            this.pictureBoxD7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxD7.Location = new System.Drawing.Point(200, 83);
            this.pictureBoxD7.Name = "pictureBoxD7";
            this.pictureBoxD7.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxD7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxD7.TabIndex = 50;
            this.pictureBoxD7.TabStop = false;
            this.pictureBoxD7.Click += new System.EventHandler(this.pictureBoxD7_Click);
            // 
            // pictureBoxC7
            // 
            this.pictureBoxC7.BackColor = System.Drawing.Color.Black;
            this.pictureBoxC7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxC7.Location = new System.Drawing.Point(150, 83);
            this.pictureBoxC7.Name = "pictureBoxC7";
            this.pictureBoxC7.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxC7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxC7.TabIndex = 49;
            this.pictureBoxC7.TabStop = false;
            this.pictureBoxC7.Click += new System.EventHandler(this.pictureBoxC7_Click);
            // 
            // pictureBoxB7
            // 
            this.pictureBoxB7.BackColor = System.Drawing.Color.White;
            this.pictureBoxB7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxB7.Location = new System.Drawing.Point(100, 83);
            this.pictureBoxB7.Name = "pictureBoxB7";
            this.pictureBoxB7.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxB7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxB7.TabIndex = 48;
            this.pictureBoxB7.TabStop = false;
            this.pictureBoxB7.Click += new System.EventHandler(this.pictureBoxB7_Click);
            // 
            // pictureBoxA7
            // 
            this.pictureBoxA7.BackColor = System.Drawing.Color.Black;
            this.pictureBoxA7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxA7.Location = new System.Drawing.Point(50, 83);
            this.pictureBoxA7.Name = "pictureBoxA7";
            this.pictureBoxA7.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxA7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxA7.TabIndex = 47;
            this.pictureBoxA7.TabStop = false;
            this.pictureBoxA7.Click += new System.EventHandler(this.pictureBoxA7_Click);
            // 
            // pictureBoxH8
            // 
            this.pictureBoxH8.BackColor = System.Drawing.Color.Black;
            this.pictureBoxH8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxH8.Location = new System.Drawing.Point(400, 33);
            this.pictureBoxH8.Name = "pictureBoxH8";
            this.pictureBoxH8.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxH8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxH8.TabIndex = 62;
            this.pictureBoxH8.TabStop = false;
            this.pictureBoxH8.Click += new System.EventHandler(this.pictureBoxH8_Click);
            // 
            // pictureBoxG8
            // 
            this.pictureBoxG8.BackColor = System.Drawing.Color.White;
            this.pictureBoxG8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxG8.Location = new System.Drawing.Point(350, 33);
            this.pictureBoxG8.Name = "pictureBoxG8";
            this.pictureBoxG8.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxG8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxG8.TabIndex = 61;
            this.pictureBoxG8.TabStop = false;
            this.pictureBoxG8.Click += new System.EventHandler(this.pictureBoxG8_Click);
            // 
            // pictureBoxF8
            // 
            this.pictureBoxF8.BackColor = System.Drawing.Color.Black;
            this.pictureBoxF8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxF8.Location = new System.Drawing.Point(300, 33);
            this.pictureBoxF8.Name = "pictureBoxF8";
            this.pictureBoxF8.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxF8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxF8.TabIndex = 60;
            this.pictureBoxF8.TabStop = false;
            this.pictureBoxF8.Click += new System.EventHandler(this.pictureBoxF8_Click);
            // 
            // pictureBoxE8
            // 
            this.pictureBoxE8.BackColor = System.Drawing.Color.White;
            this.pictureBoxE8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxE8.Location = new System.Drawing.Point(250, 33);
            this.pictureBoxE8.Name = "pictureBoxE8";
            this.pictureBoxE8.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxE8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxE8.TabIndex = 59;
            this.pictureBoxE8.TabStop = false;
            this.pictureBoxE8.Click += new System.EventHandler(this.pictureBoxE8_Click);
            // 
            // pictureBoxD8
            // 
            this.pictureBoxD8.BackColor = System.Drawing.Color.Black;
            this.pictureBoxD8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxD8.Location = new System.Drawing.Point(200, 33);
            this.pictureBoxD8.Name = "pictureBoxD8";
            this.pictureBoxD8.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxD8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxD8.TabIndex = 58;
            this.pictureBoxD8.TabStop = false;
            this.pictureBoxD8.Click += new System.EventHandler(this.pictureBoxD8_Click);
            // 
            // pictureBoxC8
            // 
            this.pictureBoxC8.BackColor = System.Drawing.Color.White;
            this.pictureBoxC8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxC8.Location = new System.Drawing.Point(150, 33);
            this.pictureBoxC8.Name = "pictureBoxC8";
            this.pictureBoxC8.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxC8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxC8.TabIndex = 57;
            this.pictureBoxC8.TabStop = false;
            this.pictureBoxC8.Click += new System.EventHandler(this.pictureBoxC8_Click);
            // 
            // pictureBoxB8
            // 
            this.pictureBoxB8.BackColor = System.Drawing.Color.Black;
            this.pictureBoxB8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxB8.Location = new System.Drawing.Point(100, 33);
            this.pictureBoxB8.Name = "pictureBoxB8";
            this.pictureBoxB8.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxB8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxB8.TabIndex = 56;
            this.pictureBoxB8.TabStop = false;
            this.pictureBoxB8.Click += new System.EventHandler(this.pictureBoxB8_Click);
            // 
            // pictureBoxA8
            // 
            this.pictureBoxA8.BackColor = System.Drawing.Color.White;
            this.pictureBoxA8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxA8.Location = new System.Drawing.Point(50, 33);
            this.pictureBoxA8.Name = "pictureBoxA8";
            this.pictureBoxA8.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxA8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxA8.TabIndex = 55;
            this.pictureBoxA8.TabStop = false;
            this.pictureBoxA8.Click += new System.EventHandler(this.pictureBoxA8_Click);
            // 
            // pictureBoxH1
            // 
            this.pictureBoxH1.BackColor = System.Drawing.Color.White;
            this.pictureBoxH1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxH1.Location = new System.Drawing.Point(400, 383);
            this.pictureBoxH1.Name = "pictureBoxH1";
            this.pictureBoxH1.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxH1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxH1.TabIndex = 70;
            this.pictureBoxH1.TabStop = false;
            this.pictureBoxH1.Click += new System.EventHandler(this.pictureBoxH1_Click);
            // 
            // pictureBoxG1
            // 
            this.pictureBoxG1.BackColor = System.Drawing.Color.Black;
            this.pictureBoxG1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxG1.Location = new System.Drawing.Point(350, 383);
            this.pictureBoxG1.Name = "pictureBoxG1";
            this.pictureBoxG1.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxG1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxG1.TabIndex = 69;
            this.pictureBoxG1.TabStop = false;
            this.pictureBoxG1.Click += new System.EventHandler(this.pictureBoxG1_Click);
            // 
            // pictureBoxF1
            // 
            this.pictureBoxF1.BackColor = System.Drawing.Color.White;
            this.pictureBoxF1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxF1.Location = new System.Drawing.Point(300, 383);
            this.pictureBoxF1.Name = "pictureBoxF1";
            this.pictureBoxF1.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxF1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxF1.TabIndex = 68;
            this.pictureBoxF1.TabStop = false;
            this.pictureBoxF1.Click += new System.EventHandler(this.pictureBoxF1_Click);
            // 
            // pictureBoxE1
            // 
            this.pictureBoxE1.BackColor = System.Drawing.Color.Black;
            this.pictureBoxE1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxE1.Location = new System.Drawing.Point(250, 383);
            this.pictureBoxE1.Name = "pictureBoxE1";
            this.pictureBoxE1.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxE1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxE1.TabIndex = 67;
            this.pictureBoxE1.TabStop = false;
            this.pictureBoxE1.Click += new System.EventHandler(this.pictureBoxE1_Click);
            // 
            // pictureBoxD1
            // 
            this.pictureBoxD1.BackColor = System.Drawing.Color.White;
            this.pictureBoxD1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxD1.Location = new System.Drawing.Point(200, 383);
            this.pictureBoxD1.Name = "pictureBoxD1";
            this.pictureBoxD1.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxD1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxD1.TabIndex = 66;
            this.pictureBoxD1.TabStop = false;
            this.pictureBoxD1.Click += new System.EventHandler(this.pictureBoxD1_Click);
            // 
            // pictureBoxC1
            // 
            this.pictureBoxC1.BackColor = System.Drawing.Color.Black;
            this.pictureBoxC1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxC1.Location = new System.Drawing.Point(150, 383);
            this.pictureBoxC1.Name = "pictureBoxC1";
            this.pictureBoxC1.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxC1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxC1.TabIndex = 65;
            this.pictureBoxC1.TabStop = false;
            this.pictureBoxC1.Click += new System.EventHandler(this.pictureBoxC1_Click);
            // 
            // pictureBoxB1
            // 
            this.pictureBoxB1.BackColor = System.Drawing.Color.White;
            this.pictureBoxB1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxB1.Location = new System.Drawing.Point(100, 383);
            this.pictureBoxB1.Name = "pictureBoxB1";
            this.pictureBoxB1.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxB1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxB1.TabIndex = 64;
            this.pictureBoxB1.TabStop = false;
            this.pictureBoxB1.Click += new System.EventHandler(this.pictureBoxB1_Click);
            // 
            // pictureBoxA1
            // 
            this.pictureBoxA1.BackColor = System.Drawing.Color.Black;
            this.pictureBoxA1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxA1.Location = new System.Drawing.Point(50, 383);
            this.pictureBoxA1.Name = "pictureBoxA1";
            this.pictureBoxA1.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxA1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxA1.TabIndex = 63;
            this.pictureBoxA1.TabStop = false;
            this.pictureBoxA1.Click += new System.EventHandler(this.pictureBoxA1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(41, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(418, 419);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 71;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 455);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 13);
            this.label2.TabIndex = 73;
            this.label2.Text = "Huo Chess move: -";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(211, 455);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 13);
            this.label3.TabIndex = 74;
            this.label3.Text = "Total final positions analyzed: -";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(605, 527);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBoxD4);
            this.Controls.Add(this.pictureBoxD2);
            this.Controls.Add(this.button_Play);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.pictureBoxH1);
            this.Controls.Add(this.pictureBoxG1);
            this.Controls.Add(this.pictureBoxF1);
            this.Controls.Add(this.pictureBoxE1);
            this.Controls.Add(this.pictureBoxD1);
            this.Controls.Add(this.pictureBoxC1);
            this.Controls.Add(this.pictureBoxB1);
            this.Controls.Add(this.pictureBoxA1);
            this.Controls.Add(this.pictureBoxH8);
            this.Controls.Add(this.pictureBoxG8);
            this.Controls.Add(this.pictureBoxF8);
            this.Controls.Add(this.pictureBoxE8);
            this.Controls.Add(this.pictureBoxD8);
            this.Controls.Add(this.pictureBoxC8);
            this.Controls.Add(this.pictureBoxB8);
            this.Controls.Add(this.pictureBoxA8);
            this.Controls.Add(this.pictureBoxH7);
            this.Controls.Add(this.pictureBoxG7);
            this.Controls.Add(this.pictureBoxF7);
            this.Controls.Add(this.pictureBoxE7);
            this.Controls.Add(this.pictureBoxD7);
            this.Controls.Add(this.pictureBoxC7);
            this.Controls.Add(this.pictureBoxB7);
            this.Controls.Add(this.pictureBoxA7);
            this.Controls.Add(this.pictureBoxH6);
            this.Controls.Add(this.pictureBoxG6);
            this.Controls.Add(this.pictureBoxF6);
            this.Controls.Add(this.pictureBoxE6);
            this.Controls.Add(this.pictureBoxD6);
            this.Controls.Add(this.pictureBoxC6);
            this.Controls.Add(this.pictureBoxB6);
            this.Controls.Add(this.pictureBoxA6);
            this.Controls.Add(this.pictureBoxH5);
            this.Controls.Add(this.pictureBoxG5);
            this.Controls.Add(this.pictureBoxF5);
            this.Controls.Add(this.pictureBoxE5);
            this.Controls.Add(this.pictureBoxD5);
            this.Controls.Add(this.pictureBoxC5);
            this.Controls.Add(this.pictureBoxB5);
            this.Controls.Add(this.pictureBoxA5);
            this.Controls.Add(this.pictureBoxH4);
            this.Controls.Add(this.pictureBoxG4);
            this.Controls.Add(this.pictureBoxF4);
            this.Controls.Add(this.pictureBoxE4);
            this.Controls.Add(this.pictureBoxC4);
            this.Controls.Add(this.pictureBoxB4);
            this.Controls.Add(this.pictureBoxA4);
            this.Controls.Add(this.pictureBoxH3);
            this.Controls.Add(this.pictureBoxG3);
            this.Controls.Add(this.pictureBoxF3);
            this.Controls.Add(this.pictureBoxE3);
            this.Controls.Add(this.pictureBoxD3);
            this.Controls.Add(this.pictureBoxC3);
            this.Controls.Add(this.pictureBoxB3);
            this.Controls.Add(this.pictureBoxA3);
            this.Controls.Add(this.pictureBoxH2);
            this.Controls.Add(this.pictureBoxG2);
            this.Controls.Add(this.pictureBoxF2);
            this.Controls.Add(this.pictureBoxE2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBoxC2);
            this.Controls.Add(this.pictureBoxB2);
            this.Controls.Add(this.pictureBoxA2);
            this.Controls.Add(this.pictureBox1);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Huo Chess 0.95 - Windows 8 edition";
            this.Click += new System.EventHandler(this.Form1_Click);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxA2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxB2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxC2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxF2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxE2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxD2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxH2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxG2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxH3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxG3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxF3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxE3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxD3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxC3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxB3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxA3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxH4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxG4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxF4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxE4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxD4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxC4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxB4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxA4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxH5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxG5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxF5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxE5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxD5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxC5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxB5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxA5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxH6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxG6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxF6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxE6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxD6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxC6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxB6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxA6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxH7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxG7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxF7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxE7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxD7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxC7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxB7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxA7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxH8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxG8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxF8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxE8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxD8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxC8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxB8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxA8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxH1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxG1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxF1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxE1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxD1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxC1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxB1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxA1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Button button_Play;
        private System.Windows.Forms.RadioButton radioButton_White;
        private System.Windows.Forms.RadioButton radioButton_Black;
        private System.Windows.Forms.GroupBox groupBox1;
        internal System.Windows.Forms.PictureBox pictureBoxA2;
        internal System.Windows.Forms.PictureBox pictureBoxB2;
        internal System.Windows.Forms.PictureBox pictureBoxC2;
        internal System.Windows.Forms.PictureBox pictureBoxF2;
        internal System.Windows.Forms.PictureBox pictureBoxE2;
        internal System.Windows.Forms.PictureBox pictureBoxD2;
        internal System.Windows.Forms.PictureBox pictureBoxH2;
        internal System.Windows.Forms.PictureBox pictureBoxG2;
        internal System.Windows.Forms.PictureBox pictureBoxH3;
        internal System.Windows.Forms.PictureBox pictureBoxG3;
        internal System.Windows.Forms.PictureBox pictureBoxF3;
        internal System.Windows.Forms.PictureBox pictureBoxE3;
        internal System.Windows.Forms.PictureBox pictureBoxD3;
        internal System.Windows.Forms.PictureBox pictureBoxC3;
        internal System.Windows.Forms.PictureBox pictureBoxB3;
        internal System.Windows.Forms.PictureBox pictureBoxA3;
        internal System.Windows.Forms.PictureBox pictureBoxH4;
        internal System.Windows.Forms.PictureBox pictureBoxG4;
        internal System.Windows.Forms.PictureBox pictureBoxF4;
        internal System.Windows.Forms.PictureBox pictureBoxE4;
        internal System.Windows.Forms.PictureBox pictureBoxC4;
        internal System.Windows.Forms.PictureBox pictureBoxB4;
        internal System.Windows.Forms.PictureBox pictureBoxA4;
        internal System.Windows.Forms.PictureBox pictureBoxH5;
        internal System.Windows.Forms.PictureBox pictureBoxG5;
        internal System.Windows.Forms.PictureBox pictureBoxF5;
        internal System.Windows.Forms.PictureBox pictureBoxE5;
        internal System.Windows.Forms.PictureBox pictureBoxD5;
        internal System.Windows.Forms.PictureBox pictureBoxC5;
        internal System.Windows.Forms.PictureBox pictureBoxB5;
        internal System.Windows.Forms.PictureBox pictureBoxA5;
        internal System.Windows.Forms.PictureBox pictureBoxH6;
        internal System.Windows.Forms.PictureBox pictureBoxG6;
        internal System.Windows.Forms.PictureBox pictureBoxF6;
        internal System.Windows.Forms.PictureBox pictureBoxE6;
        internal System.Windows.Forms.PictureBox pictureBoxD6;
        internal System.Windows.Forms.PictureBox pictureBoxC6;
        internal System.Windows.Forms.PictureBox pictureBoxB6;
        internal System.Windows.Forms.PictureBox pictureBoxA6;
        internal System.Windows.Forms.PictureBox pictureBoxH7;
        internal System.Windows.Forms.PictureBox pictureBoxG7;
        internal System.Windows.Forms.PictureBox pictureBoxF7;
        internal System.Windows.Forms.PictureBox pictureBoxE7;
        internal System.Windows.Forms.PictureBox pictureBoxD7;
        internal System.Windows.Forms.PictureBox pictureBoxC7;
        internal System.Windows.Forms.PictureBox pictureBoxB7;
        internal System.Windows.Forms.PictureBox pictureBoxA7;
        internal System.Windows.Forms.PictureBox pictureBoxH8;
        internal System.Windows.Forms.PictureBox pictureBoxG8;
        internal System.Windows.Forms.PictureBox pictureBoxF8;
        internal System.Windows.Forms.PictureBox pictureBoxE8;
        internal System.Windows.Forms.PictureBox pictureBoxD8;
        internal System.Windows.Forms.PictureBox pictureBoxC8;
        internal System.Windows.Forms.PictureBox pictureBoxB8;
        internal System.Windows.Forms.PictureBox pictureBoxA8;
        internal System.Windows.Forms.PictureBox pictureBoxH1;
        internal System.Windows.Forms.PictureBox pictureBoxG1;
        internal System.Windows.Forms.PictureBox pictureBoxF1;
        internal System.Windows.Forms.PictureBox pictureBoxE1;
        internal System.Windows.Forms.PictureBox pictureBoxD1;
        internal System.Windows.Forms.PictureBox pictureBoxC1;
        internal System.Windows.Forms.PictureBox pictureBoxB1;
        internal System.Windows.Forms.PictureBox pictureBoxA1;
        internal System.Windows.Forms.PictureBox pictureBoxD4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

